globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/e049cde4b4ae311b.js",
      "static/chunks/turbopack-d6262cad7a91a2eb.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/e049cde4b4ae311b.js",
      "static/chunks/turbopack-05a0e5c6198299d4.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/0e88b4b780bf4c60.js",
    "static/chunks/91adb7bdb9870c6a.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/150316a471952cee.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/turbopack-3c0b382d3ee3a871.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];